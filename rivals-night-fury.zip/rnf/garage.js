import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {Reflector} from 'three/addons/objects/Reflector.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
// rot = extra Y rotation if a GLB's nose does not face +Z
export const CARS=[
 {id:'pagani-huayra',name:'Pagani Huayra',pw:1.0,color:'#1b1b1f'},
 {id:'ferrari-488-pista',name:'Ferrari 488 Pista',pw:.97,color:'#e10600'},
 {id:'lamborghini-huracan-sto',name:'Lamborghini Huracán STO',pw:.95,color:'#ffb000'},
 {id:'mclaren-720s',name:'McLaren 720S',pw:1.0,color:'#1f5cff'},
 {id:'porsche-911-gt3',name:'Porsche 911 GT3',pw:.9,color:'#f2f2f2'}];
const def={car:0,paint:{},rim:{},eng:{},nos:{},coins:3000,auto:true,vol:.6,server:'http://localhost:3000'};
let sv={};try{sv=JSON.parse(localStorage.rnfSave)}catch(e){}
export const S=Object.assign({},def,sv);
export const save=()=>{try{localStorage.rnfSave=JSON.stringify(S)}catch(e){}};
export const missing=new Set();
const PAINTS=['#1b1b1f','#e10600','#ffb000','#1f5cff','#9b30ff','#00e5ff','#f2f2f2','#00c853'],RIMS=['#c8c8d0','#111111','#ffd24a','#ff2bd6','#19e6ff','#e10600'];
let env;export function makeEnv(r){if(!env)env=new THREE.PMREMGenerator(r).fromScene(new RoomEnvironment(),.04).texture;return env}
const loader=new GLTFLoader(),cache={};
function proc(c){const g=new THREE.Group(),P=new THREE.MeshPhysicalMaterial({color:c.color,metalness:.7,roughness:.25,clearcoat:1}),
 D=new THREE.MeshStandardMaterial({color:0x08080c,roughness:.5}),GL=new THREE.MeshPhysicalMaterial({color:0x111a22,metalness:.9,roughness:.05}),R=new THREE.MeshStandardMaterial({metalness:1,roughness:.2});
 const add=(geo,m,x,y,z)=>{const o=new THREE.Mesh(geo,m);o.position.set(x,y,z);g.add(o);return o},B=(w,h,d)=>new THREE.BoxGeometry(w,h,d);
 add(B(1.95,.5,4.5),P,0,.55,0);add(B(1.9,.2,1.6),P,0,.42,1.9).rotation.x=.12;add(B(1.5,.45,1.9),GL,0,.98,-.2);add(B(2,.08,.5),P,0,1.15,-2.1);
 add(B(1.6,.1,.05),new THREE.MeshBasicMaterial({color:0x19e6ff}),0,.6,2.26);add(B(1.7,.08,.05),new THREE.MeshBasicMaterial({color:0xff2222}),0,.7,-2.26);
 const W=[];for(const x of[-1,1])for(const z of[1.4,-1.4]){const w=new THREE.Group(),t=new THREE.CylinderGeometry(.36,.36,.3,24).rotateZ(Math.PI/2),r=new THREE.CylinderGeometry(.24,.24,.32,12).rotateZ(Math.PI/2);
 w.add(new THREE.Mesh(t,D),new THREE.Mesh(r,R));w.position.set(x*1.0,.36,z);g.add(w);W.push(w)}
 g.userData={paint:[P],rims:[R],wheels:W};return g}
function style(g,i){const c=CARS[i];g.userData.paint.forEach(m=>m.color.set(S.paint[c.id]||c.color));g.userData.rims.forEach(m=>m.color.set(S.rim[c.id]||'#c8c8d0'))}
export async function makeCar(i){const c=CARS[i];let car;
 try{cache[c.id]??=loader.loadAsync(`assets/cars/${c.id}.glb`);const gl=await cache[c.id],m=gl.scene.clone(true),P=[],R=[];
  m.traverse(o=>{if(!o.isMesh)return;o.material=Array.isArray(o.material)?o.material.map(x=>x.clone()):o.material.clone();const mt=[].concat(o.material);
   mt.forEach(x=>{const n=x.name+' '+o.name;if(/body|paint|exterior/i.test(n))P.push(x);else if(/rim|wheel/i.test(n)&&!/tire|tyre/i.test(n))R.push(x)})});
  m.rotation.y=c.rot||0;const s=new THREE.Vector3();new THREE.Box3().setFromObject(m).getSize(s);m.scale.setScalar(4.5/Math.max(s.x,s.z));
  const b=new THREE.Box3().setFromObject(m),ct=b.getCenter(new THREE.Vector3());m.position.set(-ct.x,-b.min.y,-ct.z);
  car=new THREE.Group();car.add(m);car.userData={paint:P,rims:R,wheels:[]}}
 catch(e){delete cache[c.id];missing.add(c.id);car=proc(c)}
 style(car,i);return car}
export class Garage{
 constructor(r,cv){const sc=this.scene=new THREE.Scene();sc.background=new THREE.Color(0x05030a);sc.fog=new THREE.Fog(0x05030a,14,40);sc.environment=makeEnv(r);sc.environmentIntensity=.5;
  this.cam=new THREE.PerspectiveCamera(45,1,.1,100);this.camZ=7.2;this.rot=.7;this.vel=0;this.drag=0;this.shift=0;this.tok=0;
  const rs=innerWidth<700?512:1024,fl=new Reflector(new THREE.PlaneGeometry(40,40),{textureWidth:rs,textureHeight:rs,color:0x777777,clipBias:.003});fl.rotation.x=-Math.PI/2;sc.add(fl);
  const ov=new THREE.Mesh(new THREE.PlaneGeometry(40,40),new THREE.MeshStandardMaterial({color:0x0a0612,transparent:true,opacity:.62,roughness:.3}));ov.rotation.x=-Math.PI/2;ov.position.y=.01;sc.add(ov);
  const tt=new THREE.Mesh(new THREE.CylinderGeometry(3.2,3.2,.06,64),new THREE.MeshStandardMaterial({color:0x15101f,metalness:.9,roughness:.2}));tt.position.y=.03;sc.add(tt);
  const neon=(c,x,y,z,w,h,d)=>{const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),new THREE.MeshBasicMaterial({color:c}));m.position.set(x,y,z);sc.add(m)};
  neon(0xff2bd6,0,5,-9,20,.12,.12);neon(0x19e6ff,0,.1,-9,20,.12,.12);neon(0xff2bd6,-10,2.5,-9,.12,5,.12);neon(0x19e6ff,10,2.5,-9,.12,5,.12);neon(0x7a3cff,-9,5,0,.12,.12,20);neon(0x7a3cff,9,5,0,.12,.12,20);
  const sp=new THREE.SpotLight(0xffffff,260,25,.6,.5,2);sp.position.set(0,9,3);sp.target.position.set(0,0,0);sc.add(sp,sp.target);
  const p1=new THREE.PointLight(0xff2bd6,40,18),p2=new THREE.PointLight(0x19e6ff,40,18);p1.position.set(-6,3,-4);p2.position.set(6,3,-4);sc.add(p1,p2);
  this.pivot=new THREE.Group();sc.add(this.pivot);
  cv.addEventListener('pointerdown',e=>{this.drag=1;this.lx=e.clientX;this.lt=performance.now();try{cv.setPointerCapture(e.pointerId)}catch(_){}});
  cv.addEventListener('pointermove',e=>{if(!this.drag)return;const n=performance.now(),dt=Math.max(.008,(n-this.lt)/1000),dx=e.clientX-this.lx;this.rot+=dx*.01;this.vel=Math.max(-8,Math.min(8,dx*.01/dt));this.lx=e.clientX;this.lt=n});
  const up=()=>this.drag=0;cv.addEventListener('pointerup',up);cv.addEventListener('pointercancel',up)}
 initUI(){const $=s=>document.querySelector(s);
  this.cards=CARS.map((c,i)=>{const d=document.createElement('div');d.className='card';d.textContent=c.name;d.onclick=()=>this.setCar(i);$('#cards').append(d);return d});
  $('#prev').onclick=()=>this.setCar((S.car+4)%5);$('#next').onclick=()=>this.setCar((S.car+1)%5);
  const sw=(box,list,key)=>list.forEach(col=>{const b=document.createElement('button');b.className='sw';b.style.background=col;b.onclick=()=>{S[key][CARS[S.car].id]=col;save();style(this.car,S.car)};$(box).append(b)});
  sw('#paints',PAINTS,'paint');sw('#rims',RIMS,'rim')}
 async setCar(i){const $=s=>document.querySelector(s),t=++this.tok,c=CARS[i];S.car=i;save();
  this.cards.forEach((d,j)=>d.classList.toggle('on',j===i));$('#gname').textContent=c.name;
  $('#gstats').textContent=`POWER ${Math.round(c.pw*100)} · ENGINE LV ${S.eng[c.id]||0} · NITROUS LV ${S.nos[c.id]||0}`;
  const car=await makeCar(i);if(t!==this.tok)return;if(this.car)this.pivot.remove(this.car);this.car=car;this.pivot.add(car);
  $('#gmiss').textContent=missing.has(c.id)?`assets/cars/${c.id}.glb not found – showing built-in stand-in`:''}
 update(dt){if(!this.drag){this.rot+=this.vel*dt;this.vel*=Math.pow(.05,dt);this.vel+=(.35-this.vel)*dt*2}
  this.pivot.rotation.y=this.rot;this.pivot.position.x+=(this.shift-this.pivot.position.x)*Math.min(1,dt*4);
  this.cam.position.z+=(this.camZ-this.cam.position.z)*Math.min(1,dt*4);this.cam.position.set(0,1.7,this.cam.position.z);this.cam.lookAt(0,.7,0)}}

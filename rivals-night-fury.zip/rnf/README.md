# Rivals Night Fury
HTML5 / Three.js neon drag racer: 3D garage, offline races vs AI, online 1v1 via Socket.IO.

## Run locally
```
npx http-server .          # serve the game (ES modules need http, not file://)
cd server && npm i && npm start   # multiplayer server on :3000
```
Three.js and socket.io-client load from jsDelivr (pinned versions), so the player needs internet.

## Car models (IMPORTANT)
Put your ORIGINAL models in `assets/cars/` with exactly these names:
`pagani-huayra.glb, ferrari-488-pista.glb, lamborghini-huracan-sto.glb, mclaren-720s.glb, porsche-911-gt3.glb`
- Auto-scaled to 4.5 m, centred, grounded. Nose must face **+Z** (else set `rot:Math.PI` for that car in `CARS` in garage.js).
- Paint recolours materials whose name contains `body`/`paint`/`exterior`; wheel colour: `rim`/`wheel` (not tire).
- A missing file is listed in the garage ("not found") and a built-in stand-in body is used. No model files were supplied, so all five are currently MISSING.

## Controls
Desktop: Space gas · Shift/E upshift · N nitrous · drag to rotate in garage. Phone: GAS / SHIFT / NOS pads, swipe to rotate. Auto-shift is on by default (Settings).
Audio: engine and beeps are synthesised (Web Audio); drop extra files in `assets/audio/` if you add your own.

## Online
Matchmaking pairs two waiting players; each client simulates its own car and streams progress (client-trusted, fine for casual play). Deploy `server/` to any Node host and paste its URL in Settings (use https/wss for an https itch page). Edit the default `server` in `garage.js`.

## itch.io
Zip the contents of this folder (index.html at the zip root, without `server/`), upload as "HTML", tick "played in the browser", viewport ~1280x720, enable fullscreen.

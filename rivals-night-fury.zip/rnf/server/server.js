const http=require('http'),{Server}=require('socket.io');
const srv=http.createServer((q,r)=>{r.writeHead(200);r.end('Rivals Night Fury server OK')});
const io=new Server(srv,{cors:{origin:'*'}});let waiting=null;
io.on('connection',s=>{
 s.on('join',d=>{s.data.car=Math.max(0,Math.min(4,(d&&d.car)|0));
  if(waiting&&waiting.connected&&waiting.id!==s.id){const a=waiting;waiting=null;const room='r'+a.id+s.id;a.join(room);s.join(room);a.data.room=s.data.room=room;
   a.emit('match',{slot:0,oppCar:s.data.car});s.emit('match',{slot:1,oppCar:a.data.car})}
  else{waiting=s;s.emit('waiting')}});
 s.on('ready',()=>{s.data.ready=true;const rm=s.data.room;if(!rm)return;const ids=[...(io.sockets.adapter.rooms.get(rm)||[])].map(i=>io.sockets.sockets.get(i));
  if(ids.length===2&&ids.every(x=>x&&x.data.ready))io.to(rm).emit('start')});
 s.on('progress',d=>{if(s.data.room)s.to(s.data.room).emit('opp',{d:+d.d||0,v:+d.v||0,fin:d.fin==null?null:+d.fin})});
 s.on('cancel',()=>{if(waiting===s)waiting=null});
 s.on('disconnect',()=>{if(waiting===s)waiting=null;if(s.data.room)s.to(s.data.room).emit('left')})});
srv.listen(process.env.PORT||3000,()=>console.log('Rivals server on',process.env.PORT||3000));

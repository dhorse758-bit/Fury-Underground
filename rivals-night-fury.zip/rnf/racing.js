import * as THREE from 'three';
import {S,save,CARS,makeCar,makeEnv} from './garage.js';
const G=[25,40,55,72,90,105],AC=[10.5,8.8,7.4,6.2,5.2,4.4],RED=8000,LEN=402;   // top speed per gear (m/s), accel per gear
const tq=r=>.62+.38*Math.sin(Math.PI*Math.min(1,Math.max(0,(r-1000)/7000)));
const $=s=>document.querySelector(s);
class Driver{
 constructor(pw,cap){Object.assign(this,{pw,cap,v:0,d:0,g:0,rpm:1000,nos:1,on:false,lock:0,fin:null})}
 get wr(){return this.v*RED/G[this.g]}
 step(dt,thr,up,nb){this.lock=Math.max(0,this.lock-dt);
  if(up&&this.g<5&&this.lock<=0){this.g++;this.lock=.18}
  const w=this.wr;let a=0;if(thr&&this.lock<=0&&w<RED)a=AC[this.g]*this.pw*tq(Math.max(w,1500));
  this.on=!!nb&&this.nos>0&&thr;if(this.on){a*=1.45;this.nos=Math.max(0,this.nos-dt/this.cap)}
  a-=.0007*this.v*this.v;this.v=Math.min(G[this.g],Math.max(0,this.v+a*dt));this.d+=this.v*dt;
  const tg=Math.max(w,thr?(this.v<8?4500:1500):1000);this.rpm+=(Math.min(RED,tg)-this.rpm)*Math.min(1,dt*10)}}
class Eng{
 start(){try{const A=this.A=new(window.AudioContext||window.webkitAudioContext)();this.o=A.createOscillator();this.p=A.createOscillator();this.g=A.createGain();
  this.o.type='sawtooth';this.p.type='square';this.g.gain.value=0;this.o.connect(this.g);this.p.connect(this.g);this.g.connect(A.destination);this.o.start();this.p.start()}catch(e){}}
 set(r,t){if(!this.A)return;const f=30+r*.045;this.o.frequency.value=f;this.p.frequency.value=f/2;this.g.gain.value=S.vol*.06*(.4+.6*t)}
 beep(f){if(!this.A)return;const o=this.A.createOscillator(),g=this.A.createGain();o.frequency.value=f;g.gain.value=.15*S.vol;o.connect(g);g.connect(this.A.destination);o.start();o.stop(this.A.currentTime+.2)}
 stop(){try{this.o.stop();this.p.stop();this.A.close()}catch(e){}}}
export class Race{
 constructor(r,o){this.r=r;this.o=o;this.scene=new THREE.Scene();this.cam=new THREE.PerspectiveCamera(60,1,.1,900);this.st='load';this.t=0;this.tc=0;this.k={};this.sh=false;this.fs=false;this.acc=0;this.ev=[];this.onEnd=()=>{};this.nl=0}
 listen(t,e,f){t.addEventListener(e,f);this.ev.push(()=>t.removeEventListener(e,f))}
 track(){const sc=this.scene,M=(c,o={})=>new THREE.MeshStandardMaterial({color:c,...o}),E=c=>new THREE.MeshBasicMaterial({color:c}),
  B=(w,h,d,m,x,y,z)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);sc.add(o);return o};
  B(14,.1,720,M(0x101018,{roughness:.25,metalness:.6}),0,-.05,300);B(40,.1,720,M(0x07070c),-27,-.06,300);B(40,.1,720,M(0x07070c),27,-.06,300);
  B(.15,.02,720,E(0xffffff),-6.8,.01,300);B(.15,.02,720,E(0xffffff),6.8,.01,300);for(let z=0;z<700;z+=8)B(.15,.02,3,E(0x8888ff),0,.01,z);
  B(14,.03,.8,E(0xffffff),0,.02,2.25);
  const cv=document.createElement('canvas');cv.width=64;cv.height=8;const x=cv.getContext('2d');for(let i=0;i<16;i++)for(let j=0;j<2;j++){x.fillStyle=(i+j)%2?'#fff':'#000';x.fillRect(i*4,j*4,4,4)}
  const tx=new THREE.CanvasTexture(cv);tx.magFilter=THREE.NearestFilter;const f=new THREE.Mesh(new THREE.PlaneGeometry(14,1.5),new THREE.MeshBasicMaterial({map:tx}));f.rotation.x=-Math.PI/2;f.position.set(0,.03,LEN+2.25);sc.add(f);
  B(.6,7,.6,E(0x00ff99),-7.2,3.5,LEN+2.25);B(.6,7,.6,E(0x00ff99),7.2,3.5,LEN+2.25);B(15,.6,.6,E(0x00ff99),0,7,LEN+2.25);
  for(let z=0;z<=LEN+100;z+=25)for(const s of[-1,1]){B(.2,6,.2,M(0x222233),s*8,3,z);B(1.2,.15,.4,E(z%50?0xff2bd6:0x19e6ff),s*7.4,6,z)}
  const lab=(t,z)=>{const c=document.createElement('canvas');c.width=256;c.height=64;const g=c.getContext('2d');g.font='bold 44px sans-serif';g.fillStyle='#19e6ff';g.textAlign='center';g.fillText(t,128,48);
   const s=new THREE.Sprite(new THREE.SpriteMaterial({map:new THREE.CanvasTexture(c),transparent:true}));s.scale.set(8,2,1);s.position.set(-9.5,4,z);sc.add(s)};
  [100,200,300].forEach(m=>lab(m+'m',m+2.25));lab('FINISH',LEN+2.25);
  const nc=[0xff2bd6,0x19e6ff,0x7a3cff];for(let i=0;i<70;i++){const w=6+Math.random()*10,h=10+Math.random()*50;B(w,h,w,M(0x0b0b16,{emissive:nc[i%3],emissiveIntensity:.18}),(i%2?1:-1)*(16+Math.random()*40),h/2,Math.random()*560)}
  sc.add(new THREE.HemisphereLight(0x6644ff,0x110022,.8));[[100,0xff2bd6],[250,0x19e6ff],[400,0xff2bd6]].forEach(([z,c])=>{const l=new THREE.PointLight(c,500,90);l.position.set(0,9,z);sc.add(l)})}
 async init(){const sc=this.scene;sc.background=new THREE.Color(0x05030f);sc.fog=new THREE.Fog(0x05030f,40,330);sc.environment=makeEnv(this.r);sc.environmentIntensity=.5;this.track();
  const slot=this.o.slot||0,lane=[-2.2,2.2],ci=S.car,oi=this.o.mode==='ai'?(ci+1+Math.floor(Math.random()*4))%5:this.o.oppCar,df=this.o.diff??1;
  this.pc=await makeCar(ci);this.oc=await makeCar(oi);this.pc.position.x=lane[slot];this.oc.position.x=lane[1-slot];sc.add(this.pc,this.oc);
  const c=CARS[ci];this.p=new Driver(c.pw*(1+.05*(S.eng[c.id]||0)),3+.5*(S.nos[c.id]||0));
  this.q=new Driver(this.o.mode==='ai'?CARS[oi].pw*[.9,.97,1.04][df]*(.97+Math.random()*.06):1,3);this.ai={react:.15+Math.random()*.3,sh:7000+Math.random()*600+df*150};
  this.eng=new Eng();this.eng.start();
  const kd=e=>{const c=e.code;if(['Space','ArrowUp','KeyW'].includes(c)){this.k.gas=1;e.preventDefault()}if(['ShiftLeft','ShiftRight','KeyE','ArrowRight'].includes(c)&&!e.repeat)this.sh=true;if(c==='KeyN'||c==='ArrowDown')this.k.nos=1},
   ku=e=>{const c=e.code;if(['Space','ArrowUp','KeyW'].includes(c))this.k.gas=0;if(c==='KeyN'||c==='ArrowDown')this.k.nos=0};
  this.listen(window,'keydown',kd);this.listen(window,'keyup',ku);
  const hold=(id,key)=>{const b=$(id),dn=e=>{e.preventDefault();this.k[key]=1},up=()=>this.k[key]=0;this.listen(b,'pointerdown',dn);this.listen(b,'pointerup',up);this.listen(b,'pointerleave',up);this.listen(b,'pointercancel',up)};
  hold('#btnGas','gas');hold('#btnNos','nos');this.listen($('#btnShift'),'pointerdown',e=>{e.preventDefault();this.sh=true});
  $('#msg').textContent='';this.lights(0,0);
  if(this.o.mode==='online'){const n=this.o.net;n.on('start',()=>this.begin());n.on('opp',m=>{m.at=performance.now();this.gh=m});n.on('left',()=>{this.left=true});$('#msg').textContent='WAITING FOR OPPONENT…'}
  else this.to=setTimeout(()=>this.begin(),600)}
 begin(){if(this.st==='load'){this.st='count';this.tc=0;$('#msg').textContent=''}}
 lights(n,g){document.querySelectorAll('#lights i').forEach((e,i)=>e.className=g?'g':i<n?'r':'')}
 end(){this.ended=true;this.st='done';const p=this.p,q=this.q,win=this.left||q.fin==null||p.fin<q.fin,coins=(win?600:200)+Math.max(0,Math.round((14-p.fin)*50));
  S.coins+=coins;save();this.onEnd({win,t:p.fin,ot:q.fin,coins,left:this.left})}
 update(dt){const p=this.p,q=this.q,on=this.o.mode==='online';
  if(this.st==='count'){this.tc+=dt;const n=Math.min(3,Math.floor(this.tc));if(n!==this.nl){this.nl=n;this.eng.beep(440)}this.lights(n,0);if(this.k.gas)this.fs=true;
   if(this.tc>=4){this.st='run';this.t=0;this.lights(3,1);this.eng.beep(880);if(this.fs)$('#msg').textContent='FALSE START!';else $('#msg').textContent='GO!';setTimeout(()=>{if(this.st==='run')$('#msg').textContent=''},900)}}
  else if(this.st==='run'){this.t+=dt;
   const thr=p.fin==null&&this.k.gas&&this.t>=(this.fs?.7:0),up=this.sh||(S.auto&&p.wr>7400);this.sh=false;p.step(dt,thr,up,this.k.nos);if(p.fin!=null)p.v*=1-.8*dt;
   if(!on){const a=this.ai;q.step(dt,q.fin==null&&this.t>=a.react,q.wr>a.sh,q.d>40&&q.g>0);if(q.fin!=null)q.v*=1-.8*dt}
   else if(this.gh){const m=this.gh,tg=m.d+m.v*(performance.now()-m.at)/1000;q.d+=(tg-q.d)*Math.min(1,dt*10);q.v=m.v;q.fin=m.fin;q.g=Math.min(5,Math.floor(m.v/18))}
   for(const d of on?[p]:[p,q])if(d.fin==null&&d.d>=LEN)d.fin=this.t-(d.d-LEN)/Math.max(d.v,1);
   if(on){this.acc+=dt;if(this.acc>.066){this.acc=0;this.o.net.send('progress',{d:p.d,v:p.v,fin:p.fin})}}
   if(!this.ended&&(this.left||(p.fin!=null&&(q.fin!=null||this.t-p.fin>(on?6:4)))))this.end()}
  this.pc.position.z=p.d;this.oc.position.z=q.d;
  (this.pc.userData.wheels||[]).forEach(w=>w.rotation.x+=p.v*dt/.36);(this.oc.userData.wheels||[]).forEach(w=>w.rotation.x+=q.v*dt/.36);
  const c=this.cam;c.fov=58+Math.min(18,p.v*.12)+(p.on?6:0);c.updateProjectionMatrix();c.position.set(this.pc.position.x*.6,2.6,p.d-7.5-p.v*.02);c.lookAt(this.pc.position.x,1,p.d+10);
  $('#spd').textContent=Math.round(p.v*3.6);$('#gear').textContent=p.g+1;const rb=$('#rpm i');rb.style.width=(p.rpm/RED*100)+'%';rb.className=p.rpm>7200?'red':'';$('#nosb i').style.width=(p.nos*100)+'%';
  $('#time').textContent=(p.fin??Math.max(0,this.t)).toFixed(2);this.eng.set(p.rpm,this.k.gas?1:0)}
 dispose(){clearTimeout(this.to);this.ev.forEach(f=>f());this.eng&&this.eng.stop()}}

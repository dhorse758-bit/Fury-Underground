import * as THREE from 'three';
import {S,save,CARS,Garage} from './garage.js';
import {Race} from './racing.js';
import {Net} from './multiplayer.js';
const $=s=>document.querySelector(s),panels=[...document.querySelectorAll('.panel')],cv=$('#c');
const renderer=new THREE.WebGLRenderer({canvas:cv,antialias:true});renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;
const garage=new Garage(renderer,cv);garage.initUI();garage.setCar(S.car);
let race=null,net=null,mode='menu',last=performance.now(),lastOpts=null;
const coins=()=>document.querySelectorAll('.coins').forEach(e=>e.textContent='⛁ '+S.coins);
function show(id){if(id&&!['loading','net'].includes(id)){mode='menu';if(id==='menu'&&race){race.dispose();race=null;net?.close();net=null}}
 panels.forEach(p=>p.classList.toggle('hidden',p.id!==id));$('#hud').classList.add('hidden');
 garage.shift=innerWidth>innerHeight&&['menu','offline','upgrades','settings'].includes(id)?1.9:0;coins()}
function resize(){const w=innerWidth,h=innerHeight;renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(w,h,false);garage.cam.aspect=w/h;garage.camZ=w<h?10:7.2;garage.cam.updateProjectionMatrix();if(race){race.cam.aspect=w/h;race.cam.updateProjectionMatrix()}}
addEventListener('resize',resize);resize();
renderer.setAnimationLoop(()=>{const n=performance.now(),dt=Math.min(.05,(n-last)/1000);last=n;
 if(mode==='race'&&race){race.update(dt);renderer.render(race.scene,race.cam)}else{garage.update(dt);renderer.render(garage.scene,garage.cam)}});
async function startRace(o){lastOpts=o;show('loading');race?.dispose();race=new Race(renderer,o);resize();await race.init();mode='race';show(null);$('#hud').classList.remove('hidden');
 race.onEnd=r=>{show('result');mode='race';$('#rtitle').textContent=r.win?(r.left?'OPPONENT LEFT – YOU WIN':'VICTORY'):'DEFEATED';
  $('#rbody').textContent=`Your time ${r.t.toFixed(2)}s`+(r.ot!=null?` · Rival ${r.ot.toFixed(2)}s`:'')+` · +⛁ ${r.coins}`;net?.close();net=null;coins()}}
async function online(){const m=$('#netmsg');show('net');m.textContent='Connecting…';net=new Net();
 try{await net.connect(S.server)}catch(e){m.textContent='Cannot reach server at '+S.server+' — run: cd server && npm i && npm start';net=null;return}
 net.on('waiting',()=>m.textContent='Searching for an opponent…');
 net.on('match',async d=>{const n=net;await startRace({mode:'online',net:n,slot:d.slot,oppCar:d.oppCar});n.send('ready')});net.send('join',{car:S.car})}
$('#netcancel').onclick=()=>{net?.send('cancel');net?.close();net=null;show('menu')};
$('#quit').onclick=()=>show('menu');
$('#again').onclick=()=>lastOpts.mode==='online'?online():startRace(lastOpts);
function upg(){const c=CARS[S.car],b=$('#upg');b.innerHTML=`<h3>${c.name}</h3>`;
 [['eng','ENGINE +5% power'],['nos','NITROUS +0.5s']].forEach(([k,l])=>{const lv=S[k][c.id]||0,cost=600*(lv+1),d=document.createElement('button');
  d.textContent=lv>=5?`${l} — MAX`:`${l} · LV ${lv}→${lv+1} · ⛁ ${cost}`;d.disabled=lv>=5||S.coins<cost;d.onclick=()=>{S.coins-=cost;S[k][c.id]=lv+1;save();coins();upg()};b.append(d)})}
const acts={menu:()=>show('menu'),garage:()=>{show('garage');garage.setCar(S.car)},race:()=>startRace({mode:'ai',diff:1}),offline:()=>show('offline'),online,
 upgrades:()=>{show('upgrades');upg()},settings:()=>{show('settings');$('#auto').checked=S.auto;$('#vol').value=S.vol;$('#srv').value=S.server}};
document.addEventListener('click',e=>{const a=e.target.closest('[data-act]')?.dataset.act;if(a)acts[a]()});
document.querySelectorAll('[data-diff]').forEach(b=>b.onclick=()=>startRace({mode:'ai',diff:+b.dataset.diff}));
$('#auto').onchange=e=>{S.auto=e.target.checked;save()};$('#vol').oninput=e=>{S.vol=+e.target.value;save()};$('#srv').onchange=e=>{S.server=e.target.value.trim();save()};
$('#reset').onclick=()=>{if(confirm('Reset all progress?')){localStorage.removeItem('rnfSave');location.reload()}};
show('menu');

// Thin Socket.IO client wrapper. Server: see /server
export class Net{
 async connect(url){const {io}=await import('https://cdn.jsdelivr.net/npm/socket.io-client@4.7.5/+esm');
  return new Promise((res,rej)=>{this.s=io(url,{transports:['websocket','polling'],timeout:6000,reconnection:false});this.s.once('connect',res);this.s.once('connect_error',rej)})}
 on(e,f){this.s&&this.s.on(e,f)}
 send(e,d){this.s&&this.s.emit(e,d)}
 close(){if(this.s){this.s.disconnect();this.s=null}}}
